package com.medicare.ProjectforMedical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProjectForMedicalApplication {


	public static void main(String[] args) {
		SpringApplication.run(ProjectForMedicalApplication.class, args);
	}

}
